package pe.edu.upeu.asistncia;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AsistnciaApplicationTests {

	@Test
	void contextLoads() {
	}

}
